package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.20-1";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-09-24 09:13"
];

1;

